//
//  Constants.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 07/06/25.
//

import Foundation

struct Constants {
    struct URLs {
        static let apiURL = "https://api.restful-api.dev/objects"
        static let pdfURL = "https://fssservices.bookxpert.co/GeneratedPDF/Companies/nadc/2024-2025/BalanceSheet.pdf"
    }
}

