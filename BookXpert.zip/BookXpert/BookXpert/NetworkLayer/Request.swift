//
//  Request.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import Foundation
protocol Request {
    var baseURL : URL { get }
    var path : String { get }
    var method : String { get }
    var headers : [String:String]? { get }
    var params : [String:Any]? { get }
    var body: Data { get }
    
    func generateRequest() throws -> URLRequest
}

extension Request {
    func generateRequest() async -> URLRequest {
        var url = baseURL.appending(path: path)
        
    }
}
