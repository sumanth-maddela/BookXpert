//
//  NetworkCall.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import Foundation

protocol NetworkProtocol {
    func performAction<T: Decodable>(url: URL?) async throws -> T
}

enum NetworkError : Error {
    case invalidURL
    case emptyData
    case decodingError
}


class NetworkManager : NetworkProtocol {
    
    static let shared = NetworkManager()
    
    private init() { }
    
    
    func performAction<T: Decodable>(url: URL?) async throws -> T {
        guard let url = url else {
            throw NetworkError.invalidURL
        }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch  {
            throw NetworkError.decodingError
        }
    }
}
