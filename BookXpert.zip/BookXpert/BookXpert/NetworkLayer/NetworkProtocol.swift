//
//  NetworkProtocol.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import Foundation
