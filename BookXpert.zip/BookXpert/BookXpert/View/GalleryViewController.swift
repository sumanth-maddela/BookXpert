//
//  GalleryViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 07/06/25.
//

import UIKit

class GalleryViewController: UIViewController ,  UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var galleryButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = .black
        setupUI()

        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        imageView.layer.cornerRadius = 8.0
        cameraButton.layer.cornerRadius = 8.0
        galleryButton.layer.cornerRadius = 8.0
    }
    
    @IBAction func cameraBtnAction(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            openImagePicker(sourceType: .camera)
        } else {
            showAlert(title: "Camera Not Available", message: "This device has no camera.")
        }
    }
    
    @IBAction func galleryBtnAction(_ sender: Any) {
        openImagePicker(sourceType: .photoLibrary)
    }
    
    func openImagePicker(sourceType: UIImagePickerController.SourceType) {
         let picker = UIImagePickerController()
         picker.delegate = self
         picker.sourceType = sourceType
         picker.allowsEditing = true // Optional
         present(picker, animated: true, completion: nil)
     }

     // MARK: - Delegate

     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
         picker.dismiss(animated: true)

         if let editedImage = info[.editedImage] as? UIImage {
             imageView.image = editedImage
         } else if let originalImage = info[.originalImage] as? UIImage {
             imageView.image = originalImage
         }
     }

     func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
         picker.dismiss(animated: true, completion: nil)
     }

     // MARK: - Helper

     func showAlert(title: String, message: String) {
         let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
         alert.addAction(UIAlertAction(title: "OK", style: .default))
         present(alert, animated: true)
     }

    
}

