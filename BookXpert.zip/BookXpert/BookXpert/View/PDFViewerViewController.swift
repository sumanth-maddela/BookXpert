//
//  PDFViewerViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 07/06/25.
//

import UIKit
import PDFKit

class PDFViewerViewController: UIViewController {

    var pdfURLString: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = .black
        view.backgroundColor = UIColor(red: 232/256, green: 228/256, blue: 220/256, alpha: 1)

        let pdfView = PDFView(frame: self.view.bounds)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true
        pdfView.backgroundColor = UIColor(red: 232/256, green: 228/256, blue: 220/256, alpha: 1)
        view.addSubview(pdfView)

        if let urlString = pdfURLString, let url = URL(string: urlString) {
            let urlSession = URLSession.shared
            let task = urlSession.dataTask(with: url) { data, response, error in
                if let data = data, let document = PDFDocument(data: data) {
                    DispatchQueue.main.async {
                        pdfView.document = document
                    }
                } else {
                    print("Failed to load PDF: \(error?.localizedDescription ?? "Unknown error")")
                }
            }
            task.resume()
        }
    }
}

