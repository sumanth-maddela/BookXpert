//
//  HomeViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//


import UIKit
import CoreData

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    let urlString = Constants.URLs.apiURL
    var gadgets : [GadgetModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = .black
        Task {
            await fetchData()
        }
        setupUI()
        registerCell()
        self.gadgets = retrieveFromCoreData()
        tableView.reloadData()
    }
    
    func setupUI() {
        titleLabel.textColor = .gray
    }
    
    func registerCell() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "GadgetTableViewCell", bundle: nil), forCellReuseIdentifier: GadgetTableViewCell.identifier)
    }

    private func fetchData() async {
        let url = URL(string: urlString)
        
        do {
            let results: [Product] = try await NetworkManager.shared.performAction(url: url)
            saveToCoreData(gadgets: results)
            print(gadgets)
            print("###COUNT --> \(gadgets.count)")
        } catch {
            print("Fetch failed with error: \(error.localizedDescription)")
        }
    }
    
    func saveToCoreData(gadgets: [Product]) {
        let context = CoreDataManager.shared.context

        for gadget in gadgets {
            let fetchRequest: NSFetchRequest<GadgetModel> = GadgetModel.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "gadID == %@", gadget.id)

            do {
                let existingProducts = try context.fetch(fetchRequest)
                if let existingProduct = existingProducts.first {
                    let dataColor = gadget.data?.dataColor
                    let capacity = gadget.data?.capacity
                    existingProduct.specOne = (dataColor?.isEmpty == false) ? dataColor : "Black"
                    existingProduct.specTwo = (capacity?.isEmpty == false) ? capacity : "256GB"
                } else {
                    let newEntity = GadgetModel(context: context)
                    newEntity.gadID = gadget.id
                    newEntity.name = gadget.name
                    newEntity.specOne = gadget.data?.dataColor ?? "Black"
                    newEntity.specTwo = gadget.data?.capacity ?? "256GB"
                }
            } catch {
                print("❌ Fetching existing product failed: \(error)")
            }
        }

        do {
            try context.save()
            self.gadgets = retrieveFromCoreData()
            tableView.reloadData()
        } catch {
            print("❌ Saving to Core Data failed: \(error)")
        }
    }

    func retrieveFromCoreData() -> [GadgetModel] {
        let context = CoreDataManager.shared.context
        
        let fetchRequest: NSFetchRequest<GadgetModel> = GadgetModel.fetchRequest()
        do {
            let gadgetModels = try context.fetch(fetchRequest)
            return gadgetModels
        } catch {
            print("❌ Fetch failed: \(error)")
            return []
        }
    }
    
    
    func showEditAlert(for index: Int) {
        let alert = UIAlertController(title: "Edit Details", message: nil, preferredStyle: .alert)
        
        let gadget = gadgets[index] // Get object
        
        alert.addTextField { textField in
            textField.placeholder = "Name"
            textField.text = gadget.name
        }
        alert.addTextField { textField in
            textField.placeholder = "Specification 1"
            textField.text = gadget.specOne
        }
        alert.addTextField { textField in
            textField.placeholder = "Specification 2"
            textField.text = gadget.specTwo
        }

        let updateAction = UIAlertAction(title: "Update", style: .default) { _ in
            let name = alert.textFields?[0].text ?? ""
            let spec1 = alert.textFields?[1].text ?? ""
            let spec2 = alert.textFields?[2].text ?? ""

            // 🔄 Update Core Data Object
            gadget.name = name
            gadget.specOne = spec1
            gadget.specTwo = spec2

            // 💾 Save Context
            do {
                try CoreDataManager.shared.context.save()
                self.gadgets = self.retrieveFromCoreData()
                self.tableView.reloadData()
            } catch {
                print("❌ Failed to save updated gadget: \(error)")
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(updateAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }

}

extension HomeViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gadgets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: GadgetTableViewCell.identifier, for: indexPath) as? GadgetTableViewCell else {
            return UITableViewCell()
        }
        
        let item = gadgets[indexPath.row]
        cell.titleLabel.text = item.name
        let specOneDesc = "Color  : \(item.specOne ?? "Black")"
        let specTwoDesc = "Storage: \(item.specTwo ?? "256GB")"
        cell.specsOneLable.text = specOneDesc
        cell.specsTwoLabel.text = specTwoDesc
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Tapped on \(gadgets[indexPath.row].name)")
        showEditAlert(for: indexPath.row)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let gadgetToDelete = gadgets[indexPath.row]
            sendDeletionNotification(for: gadgetToDelete)

            let context = CoreDataManager.shared.context
            context.delete(gadgetToDelete)

            do {
                try context.save()
                gadgets.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            } catch {
                print("❌ Failed to delete gadget: \(error)")
            }
        }
    }    
    
}

extension HomeViewController {
    
    func sendDeletionNotification(for gadget: GadgetModel) {
        let content = UNMutableNotificationContent()
        content.title = "Deleted Gadget"
        content.body = "You deleted: \(gadget.name ?? "Unknown") | \(gadget.specOne ?? "") | \(gadget.specTwo ?? "")"
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ Failed to schedule notification: \(error.localizedDescription)")
            } else {
                print("✅ Notification scheduled for deleted gadget")
            }
        }
    }

}
