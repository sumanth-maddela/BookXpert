//
//  ViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import UIKit
import GoogleSignIn
import FirebaseAuth
import Firebase
import FirebaseCore

class LoginViewController: UIViewController {
        
    @IBOutlet weak var signInButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
         super.viewDidAppear(animated)

//         if Auth.auth().currentUser != nil {
//             navigateToChooseTaskVC()
//         }
     }
    
    func setupUI() {
        signInButton.layer.cornerRadius = 12.0
    }
    
    @IBAction func signInAction(_ sender: Any) {
        signInWithGoogle(presentingViewController: self)
    }
    
    func navigateToChooseTaskVC() {
        let homeVC = ChooseTaskViewController()
        navigationController?.pushViewController(homeVC, animated: true)
        
    }
    
}

func signInWithGoogle(presentingViewController: UIViewController) {
    guard let clientID = FirebaseApp.app()?.options.clientID else { return }
    let config = GIDConfiguration(clientID: clientID)
    GIDSignIn.sharedInstance.configuration = config
    
    GIDSignIn.sharedInstance.signIn(withPresenting: presentingViewController) { result, error in
        guard error == nil else {
            print("Google Sign-In error: \(error!.localizedDescription)")
            return
        }
        
        guard let user = result?.user,
              let idToken = user.idToken?.tokenString else {
            print("Unable to get user or idToken.")
            return
        }
        
        let credential = GoogleAuthProvider.credential(
            withIDToken: idToken,
            accessToken: user.accessToken.tokenString
        )
        
        Auth.auth().signIn(with: credential) { authResult, error in
            if let error = error {
                print("Firebase Sign-In error: \(error.localizedDescription)")
                return
            }
            
            DispatchQueue.main.async {
                let homeVC = ChooseTaskViewController()
                presentingViewController.navigationController?.pushViewController(homeVC, animated: true)
            }
        }
    }
}





