//
//  ViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import UIKit

class LoginViewController: UIViewController {
        
    @IBOutlet weak var signInButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        signInButton.layer.cornerRadius = 12.0
    }
    
    @IBAction func signInAction(_ sender: Any) {
        let homeVC = ChooseTaskViewController()
        navigationController?.pushViewController(homeVC, animated: true)
    }
    
}



