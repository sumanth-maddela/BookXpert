//
//  ChooseTaskViewController.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 07/06/25.
//

import UIKit

class ChooseTaskViewController: UIViewController {
    
    
    @IBOutlet weak var pickTaskLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var pdfViewerButton: UIButton!
    @IBOutlet weak var imagePickerButton: UIButton!
    @IBOutlet weak var fetchDataButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        setupUI()
    }
    
    func setupUI() {
        imagePickerButton.layer.cornerRadius = 8
        pdfViewerButton.layer.cornerRadius = 8
        fetchDataButton.layer.cornerRadius = 8
    }
    
    @IBAction func pdfViewerAction(_ sender: Any) {
        let pdfVC = PDFViewerViewController()
        pdfVC.pdfURLString = Constants.URLs.pdfURL
        self.navigationController?.pushViewController(pdfVC, animated: true)
    }
    
    @IBAction func imagePickerAction(_ sender: Any) {
        let galleryVC = GalleryViewController()
        navigationController?.pushViewController(galleryVC, animated: true)
    }
    
    @IBAction func fetchDataAction(_ sender: Any) {
        let homeVC = HomeViewController()
        navigationController?.pushViewController(homeVC, animated: true)
    }
    
}
