//
//  GadgetTableViewCell.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import UIKit

class GadgetTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var baseView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var specsOneLable: UILabel!
    @IBOutlet weak var specsTwoLabel: UILabel!
    
    static let identifier = "GadgetTableViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        baseView.layer.cornerRadius = 8.0
    }
    
}
