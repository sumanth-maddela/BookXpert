//
//  GadgetTableViewCell.swift
//  BookXpert
//
//  Created by Sumanth Maddela on 06/06/25.
//

import UIKit

class GadgetTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var specsOneLable: UILabel!
    @IBOutlet weak var specsTwoLabel: UILabel!
    @IBOutlet weak var separatorView: UIView!
    
    static let identifier = "GadgetTableViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        separatorView.backgroundColor = .black
    }
    
}
